<?php 

	class Pakaian {
		public $warna,
			   $ukuran,
			   $bahan,
			   $harga;

		public function __construct($warna,$ukuran,$bahan,$harga) {
			$this->warna = $warna;
			$this->ukuran = $ukuran;
			$this->bahan = $bahan;
			$this->harga = $harga; 

		}

		public function getbuy(){
			return "$this->ukuran,$this->bahan";
		}
		

	}

	class CetakInfoPakaian{
		public function cetak( Pakaian $Pakaian){
			$str = "{$Pakaian->warna}  {$Pakaian->getbuy()} (Rp. {$Pakaian->harga})";
			return $str;
		}
	}

	$celana = new Pakaian("Navy", "L", "Waterproof", 50000);
	$baju = new Pakaian("Hijau","XL", "Katun", 75000);
	$infoPakaian = new CetakInfoPakaian();

	echo "Celana : ". $celana->getbuy();
	echo "<br>";
	echo "Baju   : ". $baju->getbuy();
	echo "<br>";
	echo $infoPakaian->cetak($celana);
	


?>